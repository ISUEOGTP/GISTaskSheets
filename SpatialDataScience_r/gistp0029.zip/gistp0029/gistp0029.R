# Iowa State University Extension and Outreach-Spatial Data Science Task Sheets
# GISTP 0029 Spatial Data Science with R: Joining Spatial Data with dplyr
# https://store.extension.iastate.edu/product/16611
# Last Updated: January 11, 2023; Jay Maxwell and Christopher J. Seeger

#### Getting Started ####
# Un-comment and install packages if necessary
# install.packages(c("tidyverse"),("usdata"),("sf"))

# Load the libraries
library(dplyr)
library(usdata)
library(sf)


#### Loading the Data ####
# Read the shapefile
ia_counties <- read_sf("cb_2021_us_county_20m/cb_2021_us_county_20m.shp") %>% filter(STUSPS=="IA")

# Optionally take a look at the data in the console.
glimpse(ia_counties)

# See a list of variables in the county_complete data set in the Help pane.
?county_complete

# Make a subset of data from the county_complete data set
ia_data <- county_complete %>% filter(state=="Iowa") %>% select(name, household_has_broadband_2019)

# Optionally glimpse ia_data or review in the Environemnt pane.
glimpse(ia_data)


#### Joining the Data ####
# To get descriptions of the types of joins in help
?join

# Join ia_counties and is_data based on fields NAMELSAD and name
ia_counties_joined <- ia_counties %>% left_join(ia_data, by=c("NAMELSAD"="name"))

# Create a basic plot the subsetted data for household_has_broadband_2019
ia_counties_joined %>% select(household_has_broadband_2019)%>% plot()

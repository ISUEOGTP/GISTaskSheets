# Iowa State University Extension and Outreach-Spatial Data Science Task Sheets
# GISTP 0027 Spatial Data Science with R: Importing CSV and Excel Data
# https://store.extension.iastate.edu/product/16609
# Last Updated: December 20, 2022; Jay Maxwell and Christopher J. Seeger

#### Importing CSV Data   ####
data1 <- read.csv("deaths.csv", header=TRUE)

#### Importing CSV Data from a Web Server ####
url <- "https://isueogtp.github.io/GISTaskSheets/Data/HS_Graduation_Rates.csv"
data2 <- read.csv(url, header=TRUE)

#### Importing Data from Excel Spreadsheets ####
# install.packages("readxl")
library(readxl)
data3 <- read_xlsx("population.xlsx")



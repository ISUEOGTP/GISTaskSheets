# Iowa State University Extension and Outreach-Spatial Data Science Task Sheets
# GISTP 0028 Spatial Data Science with R: Plotting a Shapefile with sf
# https://store.extension.iastate.edu/product/16610
# Last Updated: December 21, 2022; Jay Maxwell and Christopher J. Seeger


#### Getting Started ####
# Install the sf package
install.packages("sf")

# If needed, un-comment and install the tidyverse
#install.packages("tidyverse")

# Load the sf and dplyr package
library(sf)
library(dplyr)


#### Using the Simple Features Package ####

# Read the state boundaries shapefile
all_states <- read_sf("cb_2021_us_state_20m/cb_2021_us_state_20m.shp")

# See the NAMEs of each item in the data set
all_states$NAME

# Access the spatial data
st_geometry(all_states)

# Visualize the geometry
all_states %>% st_geometry() %>% plot()


#### Working with Spatial Data Frames ####
# Which classes does all_states inherit from?
class(all_states)


# View the  largest states by square miles, decreasing
all_states %>% 
  arrange(desc(ALAND)) %>% 
  head() %>% 
  st_geometry() %>% 
  plot()

# Subset the spatial data to Iowa and the surrounding states.
ia_surrounding <- all_states %>%
  filter(NAME %in% c("Iowa", "Nebraska", "Minnesota", "South Dakota", "Illinois", "Missouri", "Wisconsin")) %>% 
  select("GEOID", "NAME", "geometry")

# Plot the subsetted data
ia_surrounding %>% st_geometry() %>% plot()